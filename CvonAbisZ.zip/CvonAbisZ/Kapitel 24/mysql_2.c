#include<stdio.h>
#include<stdlib.h>
#if defined __WIN32__ || _MSC_VER
   #include "my_global.h"
   #include "mysql.h"
#else
   #include <mysql.h>
#endif

int main (int argc, char *argv[]) {
   int i;
   char *groups[] = {
      "client", "WinMySQLadmin", NULL
   };

   my_init ();
   printf ("Urspr�ngliche Argumente:\n");
   for (i = 0; i < argc; i++)
      printf ("argv[%d] : %s\n", i, argv[i]);

   load_defaults ("my", (const char **)groups, &argc, &argv);

   printf ("Angepasste Argumente nach load_default():\n");
   for (i = 0; i < argc; i++)
      printf ("argv[%d] : %s\n", i, argv[i]);
   return EXIT_SUCCESS;
}
