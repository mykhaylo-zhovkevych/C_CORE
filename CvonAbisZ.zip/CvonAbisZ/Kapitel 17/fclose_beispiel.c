#include<stdio.h>
#include<stdlib.h>

int main(void) {
   FILE *quell,*ziel;
   char quellname[20],zielname[20];
   int c, wahl;

   printf("Bitte geben Sie den Namen der Zieldatei an : ");
   scanf("%19s",zielname);
   if( (ziel=fopen(zielname,"a+")) == NULL) {
      printf("Konnte \"%s\" nicht erstellen bzw. finden!\n",
         zielname);
      printf("...oder Sie haben unzureichende Rechte \n");
      return EXIT_FAILURE;
   }

   do {
      printf("Welche Datei wollen Sie in "
             "die Zieldatei schreiben,\n");
      printf("bzw. anh�ngen (name.xxx) : ");
      scanf("%19s",quellname);
      quell= fopen(quellname,"r");
      if(NULL == quell) {
         printf("Konnte %s nicht �ffnen!\n",quellname);
         return EXIT_FAILURE;
      }
      else {
         while((c=getc(quell)) != EOF)
            putc(c,ziel);
         fclose(quell);
      }
      printf("Weitere Datei an %s anh�ngen (1=ja/2=nein): ",
         zielname);
      scanf("%1d",&wahl);
   } while(wahl == 1);
   return EXIT_SUCCESS;
}
